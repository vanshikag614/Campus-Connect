'use strict';

angular.
  module('eventApp').
  config(['$routeProvider',
    function config($routeProvider) {
      $routeProvider.
        when('/events', {
          template: '<event-list></event-list>'
        }).
        when('/events/:eventName', {
          template: '<event-detail></event-detail>'
        }).
        otherwise('/events');
    }
  ]);
