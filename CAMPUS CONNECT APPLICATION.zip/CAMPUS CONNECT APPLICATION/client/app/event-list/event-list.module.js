'use strict';

angular.module('eventList', []);
