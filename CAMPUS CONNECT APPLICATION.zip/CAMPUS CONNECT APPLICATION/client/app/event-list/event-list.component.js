"use strict";

angular.module("eventList").component("eventList", {
  templateUrl: "event-list/event-list.template.html",
  controller: function ($scope, $http) {
    console.log("in home");
    $http.get("http://localhost:3000/events").then(function (response) {
      console.log(response);
      $scope.events = response.data;
    });
  },
});
