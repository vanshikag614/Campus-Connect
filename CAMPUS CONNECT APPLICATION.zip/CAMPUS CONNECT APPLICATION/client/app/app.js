var app = angular.module("app", ["ngRoute"]);

app.config(function ($routeProvider) {
  $routeProvider
    .when("/home", {
      templateUrl: "home.html",
      controller: "homeController",
    })
    .when("/about", {
      templateUrl: "about.html",
      controller: "aboutController",
    })
    .when("/login", {
      templateUrl: "login.html",
      controller: "loginController",
    })
    .otherwise({
      redirectTo: "/home",
    });
});
