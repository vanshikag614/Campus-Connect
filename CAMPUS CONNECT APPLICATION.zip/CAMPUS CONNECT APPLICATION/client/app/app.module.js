'use strict';

angular.module('eventApp', [
  'ngRoute',
  'eventList',
  'eventDetail'
]);
