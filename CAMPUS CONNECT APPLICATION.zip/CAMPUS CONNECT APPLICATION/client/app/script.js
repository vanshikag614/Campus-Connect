document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default anchor action
        const sectionId = this.getAttribute('data-section');
        
        document.querySelectorAll('section').forEach((section) => {
            section.classList.add('hidden'); // Hide all sections
        });

        document.getElementById(sectionId).classList.remove('hidden'); // Show the clicked section
    });
});
