'use strict';

angular.
  module('eventDetail').
  component('eventDetail', {
    templateUrl: 'event-detail/event-detail.template.html',
    controller: function ($scope, $http, $routeParams) {
      console.log("in home");
      const url = "http://localhost:3000/events/" + $routeParams.eventName;
      $http.get(url).then(function (response) {
        console.log(response);
        $scope.selectedEvent = response.data;
      });
    },
  });
