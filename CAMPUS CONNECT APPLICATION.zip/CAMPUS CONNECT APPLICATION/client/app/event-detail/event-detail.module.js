'use strict';

angular.module('eventDetail', [
  'ngRoute',
]);
