var app = angular.module("app", ["ngRoute"]);

app.controller('mainController', function($scope) {
    // Main controller logic if needed
});

app.controller('homeController', function ($scope, $http) {
    console.log("in home")
    $http.get('http://localhost:3000/events')
        .then(function (response) {
            console.log(response);
            $scope.events = response.data;
        });

    $scope.register = function (event) {
        $scope.selectedEvent = event;
        $('#registerModal').modal('show');
    };
});

app.controller('aboutController', function($scope) {
    $scope.message = 'About Us Page';
});

app.controller('loginController', function($scope) {
    $scope.user = {};

    $scope.login = function() {
        if ($scope.user.username && $scope.user.password) {
            alert('Login successful (simulation)');
            // Normally you would send the data to the server for validation
            console.log('Logging in with:', $scope.user.username, $scope.user.password);
        } else {
            alert('Please fill in both fields');
        }
    };
});
