const express = require("express");
const { MongoClient, ServerApiVersion, ObjectId } = require("mongodb");

const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(express.json());

const dbName = "campusconnect";
const eventCollection = "events";
const userCollection = "users";
const registerCollection = "eventregistration";

const uri =
  "mongodb+srv://spandanasj24:3J8Qp0WWF41W8uuI@cluster0.s6ttefk.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
});

const database = client.db(dbName);

const start = async () => {
  try {
    app.listen(3000, () => console.log("Server started on port 3000"));
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

// API endpoints

// Get list of events
app.get("/events", async (req, res) => {
  try {
    const collection = database.collection(eventCollection);
    await client.connect();
    const events = await collection.find().toArray();
    if (events === null) {
      console.log("Couldn't find.\n");
    }
    await client.close();
    res.set("Access-Control-Allow-Origin", "http://localhost:8000");
    return res.status(200).json(events);
  } catch (err) {
    console.error(`Something went wrong trying to find one document: ${err}\n`);
  }
});

app.get("/events/:eventname", async (req, res) => {
  try {
    const collection = database.collection(eventCollection);
    const eventName = req.params.eventname;
    await client.connect();
    const query = {
      eventname: eventName,
    };

    const event = await collection.findOne(query);
    if (event === null) {
      console.log("Couldn't find.\n");
    }
    await client.close();
    res.set("Access-Control-Allow-Origin", "http://localhost:8000");
    return res.status(200).json(event);
  } catch (err) {
    console.error(`Something went wrong trying to find one document: ${err}\n`);
  }
});

// Register user

// Login user
app.post("/authenticateuser", async (req, res) => {
  try {
    const details = req.body;
    const collection = database.collection(userCollection);
    await client.connect();
    const query = {
      username: details.username,
      userpassword: details.userpassword,
    };
    const user = await collection.findOne(query);
    const result = {
      success: false,
    };
    if (user == null) {
      console.log("Login as guest.Could not find user.\n");
      result.success = false;
    } else {
      console.log("Login successful");
      result.success = true;
    }
    await client.close();
    return res.status(200).json(result);
  } catch (err) {
    console.error(`Something went wrong trying to find one document: ${err}\n`);
  }
});
// Guest Login
app.post("/registerguest", async (req, res) => {
  try {
    const details = req.body;
    const collection = database.collection(userCollection);
    await client.connect();
    const query = {
      username: details.username,
    };
    const user = await collection.findOne(query);

    const result = {
      success: false,
      userDetails: null,
    };
    if (user == null) {
      console.log("Login as guest.Could not find user.\n");
      result.success = true;

      // Generate a random UUID
      const random_uuid = uuidv4();

      // Print the UUID
      console.log(random_uuid);
      const newuser = { username: details.username, userpassword: random_uuid };
      await collection.insertOne(newuser);
      result.userDetails = newuser;
    } else {
      console.log("Aldready existing user");
      result.success = false;
    }
    await client.close();
    return res.status(200).json(result);
  } catch (err) {
    console.error(`Something went wrong trying to find one document: ${err}\n`);
  }
});

//Register Events
app.post("/registerevent", async (req, res) => {
  try {
    const details = req.body;
    const collection1 = database.collection(registerCollection);
    const collection2 = database.collection(userCollection);
    const collection3 = database.collection(eventCollection);
    await client.connect();
    const query1 = {
      username: details.username,
      eventname: details.eventname,
    };
    const query2 = {
      username: details.username,
    };
    const query3 = {
      eventname: details.eventname,
    };

    const eventRegistration = await collection1.findOne(query1);
    const user = await collection2.findOne(query2);
    const event = await collection3.findOne(query3);
    const result = {
      success: true,
      reason: null,
    };
    if (user == null) {
      result.success = false;
      result.reason = 1; // User not found
      console.log("Couldn't find user");
    } else if (event == null) {
      result.success = false;
      result.reason = 2; // Event not found
      console.log("Couldn't find event");
    } else if (eventRegistration != null) {
      result.success = false;
      result.reason = 3; // User already registered for event
      console.log("User already registered for event");
    } else if (eventRegistration == null) {
      // Successfully registerd user for the event
      const relation = {
        username: details.username,
        eventname: details.eventname,
      };
      await collection1.insertOne(relation);
      result.success = true;
    }
    await client.close();
    return res.status(200).json(result);
  } catch (err) {
    console.error(`Something went wrong trying to find one document: ${err}\n`);
  }
});
start();
