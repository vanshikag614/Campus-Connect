const express = require("express");
const mongoose = require("mongoose");
const { Event } =require("./model");

const app = express();
app.use(express.json());
app.get("/events",async (req,res) => {
    const allEvents = await Event.find();
    return res.status(200).json(allEvents);
});


const start = async () => {
  try {
    await mongoose.connect(
      "mongodb+srv://spandanasj24:3J8Qp0WWF41W8uuI@cluster0.s6ttefk.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
    );
    app.listen(3000, () => console.log("Server started on port 3000"));
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

start();