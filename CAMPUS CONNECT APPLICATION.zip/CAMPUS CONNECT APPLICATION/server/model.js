const mongoose = require("mongodb");
const EventSchema = new mongoose.Schema({
    eventname: {
        type: String,
        required: true,
    },
    eventdate: {
        type: Date,
        required: true,
    },
    eventlocation: {
        type: String,
        required: true
    },
});
const Event = mongoose.model("Event",EventSchema);
module.exports = { Event };